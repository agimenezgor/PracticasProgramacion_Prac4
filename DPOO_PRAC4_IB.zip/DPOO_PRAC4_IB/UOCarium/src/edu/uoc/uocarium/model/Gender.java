package edu.uoc.uocarium.model;

public enum Gender {
	MALE, FEMALE;
}
